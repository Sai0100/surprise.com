package org.hack.surprise.com.main.controller;

import org.springframework.stereotype.Component;

@Component
public class ServiceController {

}
