/**
 * 
 */
(function(angular) {
	'use strict';
	angular.module('surprise', ['ui.bootstrap', 'ui.router','ngCookies']);
})(window.angular);