package org.hack.surprise.com.main.service;

import java.util.List;

import org.hack.surprise.com.main.model.Request;
import org.hack.surprise.com.main.model.User;

public class ServiceManagerImpl implements ServiceManager {

	@Override
	public List<User> getHelperList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getSenderList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addGift() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Request> getGiftRequests() {
		// TODO Auto-generated method stub
		return null;
	}

}
