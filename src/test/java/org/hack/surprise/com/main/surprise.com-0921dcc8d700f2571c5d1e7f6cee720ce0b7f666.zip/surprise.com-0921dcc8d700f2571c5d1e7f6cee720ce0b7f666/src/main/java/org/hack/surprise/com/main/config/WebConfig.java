package org.hack.surprise.com.main.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class WebConfig {
}
